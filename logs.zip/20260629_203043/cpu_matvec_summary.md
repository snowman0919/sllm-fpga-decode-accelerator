# CPU MatVec Baseline Summary

- backend: cpu_numpy_int32
- input_dim: 16
- output_dim: 4
- runs: 3
- correctness_pass: True
- total_latency_ms_mean: 0.051
- total_latency_ms_p50: 0.0284
- total_latency_ms_p95: 0.09392
- compute_latency_ms_mean: 0.0169
- effective_macs_per_s: 1254901.954
- log_dir: C:\Users\dbsgu\Dev\ai_accel_jtag_test\logs\20260629_203043
