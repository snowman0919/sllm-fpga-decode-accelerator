# ORT MatVec CPU Micrograph Summary

- backend: onnxruntime_cpu
- graph: matvec_cpu_baseline.onnx
- provider: CPUExecutionProvider
- custom_op: False
- input_dim: 16
- output_dim: 4
- dtype: float32
- runs: 3
- correctness_pass: True
- latency_ms_mean: 0.1859
- latency_ms_p50: 0.0297
- latency_ms_p95: 0.46467
- log_dir: C:\Users\dbsgu\Dev\ai_accel_jtag_test\logs\20260629_203043
